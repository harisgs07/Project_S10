'use strict'

// Default to the Chrome config:
exports.config = require('./conf/chrome').config
